#!/usr/bin/env python3
"""Independently reconcile actual CSV, SQL receipts and read-only SQLite data."""
from __future__ import annotations

import argparse
import csv
from contextlib import closing
from datetime import date
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
from pathlib import Path
import sqlite3


def read(path: Path) -> bytes:
    if not path.is_file() or path.is_symlink() or path.stat().st_size > 8 * 1024 * 1024:
        raise ValueError(f"文件缺失、链接或超过 8 MiB：{path.name}")
    return path.read_bytes()


def sha(path: Path) -> str:
    return hashlib.sha256(read(path)).hexdigest()


def folder(feature_dir: Path) -> Path:
    path = feature_dir / "warehouse"
    if (not feature_dir.is_dir() or feature_dir.is_symlink() or not path.is_dir()
            or path.is_symlink() or getattr(path, "is_junction", lambda: False)()):
        raise ValueError("需要当前 Feature 内的普通 warehouse 目录")
    return path


def assessment(feature_dir: Path) -> dict:
    target = folder(feature_dir)
    raw = read(target / "orders.csv")
    reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
    if reader.fieldnames != ["order_id", "customer_id", "order_date", "amount", "status"]:
        raise ValueError("CSV 列不匹配订单合同")
    rows = list(reader)
    if not rows or len(rows) > 5000:
        raise ValueError("订单记录必须为 1–5000 行")
    source_rows = []
    expected_daily = {}
    invalid_dates = []
    for index, row in enumerate(rows, 2):
        try:
            amount = Decimal(row["amount"])
            if not amount.is_finite() or amount != amount.quantize(Decimal("0.01")):
                raise ValueError("金额必须为有限两位小数")
            cents = int(amount * 100)
        except (InvalidOperation, KeyError, TypeError) as error:
            raise ValueError("金额或 CSV 记录无效") from error
        source_rows.append((row["order_id"], row["customer_id"], row["order_date"], cents, row["status"]))
        try:
            if date.fromisoformat(row["order_date"]).isoformat() != row["order_date"]:
                invalid_dates.append(index)
        except ValueError:
            invalid_dates.append(index)
        if row["status"] in ["paid", "completed"]:
            day = expected_daily.setdefault(row["order_date"], {"order_count": 0, "amount_cents": 0})
            day["order_count"] += 1
            day["amount_cents"] += cents
    model = json.loads(read(target / "MODEL.json").decode("utf-8"))
    run = json.loads(read(target / "SQL_RUN.json").decode("utf-8"))
    database = target / "local_orders.sqlite3"
    read(database)
    with closing(sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True)) as connection:
        connection.execute("PRAGMA query_only=ON")
        integrity = connection.execute("PRAGMA quick_check").fetchone()[0]
        actual_rows = connection.execute("SELECT order_id,customer_id,order_date,amount_cents,status FROM dwd_order").fetchall()
        actual_daily = [{"order_date": row[0], "order_count": row[1], "amount_cents": row[2]}
                        for row in connection.execute("SELECT order_date,order_count,amount_cents FROM dws_order_daily ORDER BY order_date")]
    checks = []
    def check(identifier, passed, expected, actual):
        checks.append({"id": identifier, "passed": bool(passed), "expected": expected, "actual": actual})
    provenance = {"modelSha256": sha(target / "MODEL.json"), "csvSha256": sha(target / "orders.csv"),
                  "sqlSha256": sha(target / "orders_transform.sql"), "databaseSha256": sha(database),
                  "resultsSha256": sha(target / "SQL_RESULTS.json")}
    check("actual_sql_execution", run.get("apiVersion") == "warehouse.sql-run/v1" and run.get("executed") is True
          and run.get("engine") == "sqlite3" and all(run.get(key) == value for key, value in provenance.items()),
          "matching actual model/CSV/SQL/database/result byte hashes", {key: run.get(key) for key in provenance})
    check("model_contract", model.get("apiVersion") == "warehouse.model/v1" and model.get("grain") == ["order_id"]
          and model.get("validStatuses") == ["paid", "completed"] and model.get("currency") == "CNY"
          and model.get("scale") == 2 and model.get("input", {}).get("sha256") == provenance["csvSha256"]
          and model.get("requestSha256") == sha(target / "INPUT.json"), "declared CNY order contract with current input", model.get("input"))
    document_matches = True
    for document in model.get("documents", []):
        relative = Path(document["path"])
        path = feature_dir / relative
        if relative.is_absolute() or ".." in relative.parts or not path.resolve().is_relative_to(feature_dir.resolve()):
            raise ValueError("模型声明的文档路径越界")
        document_matches = document_matches and sha(path) == document["sha256"]
    check("requirements_snapshot", bool(model.get("documents")) and document_matches, "unchanged PRD and specification bytes", document_matches)
    check("sqlite_integrity", integrity == "ok", "ok", integrity)
    ids = [row[0] for row in source_rows]
    check("order_id_unique", all(identifier.strip() for identifier in ids) and len(set(ids)) == len(ids), len(ids), len(set(ids)))
    missing_customers = sum(not row[1].strip() for row in source_rows)
    check("customer_required", not missing_customers, 0, missing_customers)
    check("iso_order_date", not invalid_dates, [], invalid_dates)
    negatives = sum(row[3] < 0 for row in source_rows)
    check("non_negative_amount", not negatives, 0, negatives)
    unknown = sorted({row[4] for row in source_rows} - {"paid", "completed", "cancelled"})
    check("known_status", not unknown, [], unknown)
    check("row_count_reconciliation", len(source_rows) == len(actual_rows), len(source_rows), len(actual_rows))
    check("detail_row_reconciliation", sorted(source_rows) == sorted(actual_rows), "every source row preserved", sorted(source_rows) == sorted(actual_rows))
    source_raw = sum(row[3] for row in source_rows)
    actual_raw = sum(row[3] for row in actual_rows)
    check("amount_reconciliation", source_raw == actual_raw, source_raw, actual_raw)
    expected = [{"order_date": day, **values} for day, values in sorted(expected_daily.items())]
    check("daily_reconciliation", expected == actual_daily, expected, actual_daily)
    valid_rows = sum(row[4] in ["paid", "completed"] for row in source_rows)
    valid_amount = sum(row[3] for row in source_rows if row[4] in ["paid", "completed"])
    check("valid_row_count_reconciliation", sum(row["order_count"] for row in actual_daily) == valid_rows, valid_rows, sum(row["order_count"] for row in actual_daily))
    check("valid_amount_reconciliation", sum(row["amount_cents"] for row in actual_daily) == valid_amount, valid_amount, sum(row["amount_cents"] for row in actual_daily))
    passed = all(item["passed"] for item in checks)
    return {"apiVersion": "warehouse.quality/v1", "engine": "sqlite3", "scope": "local_sqlite_contract_demo",
            "qualityStatus": "passed" if passed else "failed", "checks": checks, "provenance": provenance,
            "summary": {"inputRows": len(rows), "validRows": valid_rows, "rawAmountCents": source_raw,
                        "validAmountCents": valid_amount, "daily": actual_daily},
            "businessAcceptance": "needs_review", "productionAcceptance": "not_evaluated",
            "limits": "仅验证当前本地 CSV 与 SQLite SQL 的明确口径；未连接生产数仓，未评估生产权限、性能、调度和数据完整性。"}


def markdown(report: dict) -> str:
    lines = ["# 本地订单数仓质量校验", "", f"本地检查：{report['qualityStatus']}；业务认可：needs_review；生产验收：not_evaluated。", "",
             f"输入 {report['summary']['inputRows']} 行；有效 {report['summary']['validRows']} 行；有效金额 {Decimal(report['summary']['validAmountCents']) / 100:.2f} CNY。", "",
             "| 检查 | 结果 |", "|---|---|"]
    lines += [f"| {item['id']} | {'passed' if item['passed'] else 'FAILED'} |" for item in report["checks"]]
    return "\n".join([*lines, "", report["limits"], ""])


def validate(feature_dir: Path) -> list[str]:
    try:
        report = assessment(feature_dir)
        target = folder(feature_dir)
        errors = [f"真实本地质量检查失败：{item['id']}" for item in report["checks"] if not item["passed"]]
        if json.loads(read(target / "QUALITY.json").decode("utf-8")) != report:
            errors.append("质量报告与实际数据/SQL字节不一致；须重新检查")
        if read(target / "QUALITY.md").decode("utf-8") != markdown(report):
            errors.append("质量报告正文不一致")
        return errors
    except (OSError, ValueError, UnicodeError, sqlite3.Error, KeyError, TypeError) as error:
        return [str(error)]


def execute_check(feature_dir: Path) -> dict:
    report = assessment(feature_dir)
    target = folder(feature_dir)
    for name, text in [("QUALITY.json", json.dumps(report, ensure_ascii=False, indent=2) + "\n"), ("QUALITY.md", markdown(report))]:
        path = target / name
        if path.is_symlink() or (path.exists() and not path.is_file()):
            raise ValueError("报告输出不能是目录或链接")
        path.write_text(text, encoding="utf-8", newline="\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["check", "validate"])
    parser.add_argument("--feature-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "check":
            result = execute_check(args.feature_dir)
            print(json.dumps(result, ensure_ascii=False))
            raise SystemExit(0 if result["qualityStatus"] == "passed" else 1)
        errors = validate(args.feature_dir)
        print(json.dumps({"ok": not errors, "errors": errors}, ensure_ascii=False))
        raise SystemExit(1 if errors else 0)
    except (OSError, ValueError, UnicodeError, sqlite3.Error, KeyError, TypeError) as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False))
        raise SystemExit(1)
