/** Context execution and the knowledge Skill are declared by the package contract.
 * No guest hook takes over the original workflow or its business checks.
 */
export function register() {}

