#!/usr/bin/env python3
"""Materialize an explicit order-warehouse contract from real local inputs."""
from __future__ import annotations

import argparse
import csv
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
from pathlib import Path

COLUMNS = ["order_id", "customer_id", "order_date", "amount", "status"]
DEMO_CSV = """order_id,customer_id,order_date,amount,status
O1001,C001,2026-10-01,120.50,paid
O1002,C002,2026-10-01,80.00,completed
O1003,C001,2026-10-02,35.25,paid
O1004,C003,2026-10-02,49.90,cancelled
O1005,C002,2026-10-03,200.00,completed
"""


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def folder(feature_dir: Path, *, create: bool = False) -> Path:
    if not feature_dir.is_dir() or feature_dir.is_symlink():
        raise ValueError("Feature 目录必须是已存在的普通目录")
    target = feature_dir / "warehouse"
    if target.is_symlink() or getattr(target, "is_junction", lambda: False)():
        raise ValueError("warehouse 不允许链接")
    if create:
        target.mkdir(exist_ok=True)
    if not target.is_dir():
        raise ValueError("请先使用明确的输入来源初始化 warehouse")
    return target


def read(path: Path) -> bytes:
    if (not path.is_file() or path.is_symlink() or path.stat().st_size > 2 * 1024 * 1024
            or getattr(path, "is_junction", lambda: False)()):
        raise ValueError(f"文件缺失、链接或超过 2 MiB：{path.name}")
    return path.read_bytes()


def write(path: Path, text: str) -> None:
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise ValueError("输出必须是普通文件")
    path.write_text(text, encoding="utf-8", newline="\n")


def rows(raw: bytes) -> list[dict]:
    reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
    if reader.fieldnames != COLUMNS:
        raise ValueError("CSV 列必须依次为 " + ",".join(COLUMNS))
    items = list(reader)
    if not items or len(items) > 5000 or any(None in item or None in item.values() for item in items):
        raise ValueError("CSV 必须为 1–5000 条完整记录")
    for item in items:
        try:
            value = Decimal(item["amount"])
            if not value.is_finite() or value != value.quantize(Decimal("0.01")) or abs(value) > Decimal("999999999.99"):
                raise ValueError("金额必须有限、最多两位小数且不超过 999999999.99")
        except InvalidOperation as error:
            raise ValueError("amount 必须为有效十进制金额") from error
    return items


def initialize(feature_dir: Path, source: Path | None = None) -> dict:
    target = folder(feature_dir, create=True)
    if any((target / name).exists() for name in ["orders.csv", "INPUT.json"]):
        raise ValueError("输入已存在；不会用演示数据覆盖用户文件")
    raw = read(source) if source else DEMO_CSV.encode("utf-8")
    items = rows(raw)
    request = {"apiVersion": "warehouse.input/v1", "sourceMode": "user_csv" if source else "explicit_local_demo",
               "sourceName": source.name if source else "five-orders-demo.csv", "inputRows": len(items),
               "currency": "CNY", "validStatuses": ["paid", "completed"], "excludedStatuses": ["cancelled"],
               "scope": "local_sqlite_contract_demo", "productionAcceptance": "not_evaluated"}
    write(target / "orders.csv", raw.decode("utf-8-sig"))
    write(target / "INPUT.json", json.dumps(request, ensure_ascii=False, indent=2) + "\n")
    return request


def contract(feature_dir: Path) -> dict:
    target = folder(feature_dir)
    raw = read(target / "orders.csv")
    items = rows(raw)
    request = json.loads(read(target / "INPUT.json").decode("utf-8"))
    if (request.get("apiVersion") != "warehouse.input/v1" or request.get("currency") != "CNY"
            or request.get("validStatuses") != ["paid", "completed"]
            or request.get("excludedStatuses") != ["cancelled"]
            or request.get("sourceMode") not in ["explicit_local_demo", "user_csv"]):
        raise ValueError("本 Mod 仅实现已明确的 CNY 订单口径；变更口径须改业务实现并重新检查")
    documents = [feature_dir / "PRD.md", feature_dir / "proposal.md", *sorted((feature_dir / "specs").glob("**/*.md"))]
    if len(documents) < 3:
        raise ValueError("需要真实 PRD、proposal 与至少一份规格")
    for path in documents:
        if not read(path).strip() or not path.resolve().is_relative_to(feature_dir.resolve()):
            raise ValueError("需求或规格文档缺失、为空或越界")
    return {"apiVersion": "warehouse.model/v1", "engine": "sqlite3", "scope": "local_sqlite_contract_demo",
            "sourceMode": request["sourceMode"], "input": {"path": "warehouse/orders.csv", "sha256": hashlib.sha256(raw).hexdigest(), "rows": len(items)},
            "requestSha256": digest(target / "INPUT.json"),
            "documents": [{"path": path.relative_to(feature_dir).as_posix(), "sha256": digest(path)} for path in documents],
            "grain": ["order_id"], "dimensions": ["customer_id", "order_date"], "measure": "amount_cents",
            "currency": "CNY", "scale": 2, "validStatuses": ["paid", "completed"], "excludedStatuses": ["cancelled"],
            "tables": {"detail": "dwd_order", "daily": "dws_order_daily"},
            "qualityRules": ["order_id_unique", "customer_required", "iso_order_date", "non_negative_amount", "known_status", "row_count_reconciliation", "amount_reconciliation", "daily_reconciliation"],
            "businessAcceptance": "needs_review", "productionAcceptance": "not_evaluated"}


def markdown(model: dict) -> str:
    return "\n".join(["# 订单数仓模型契约", "", "范围：本地 SQLite，可复核订单样例；生产环境未验收。", "",
        "- 明细粒度：order_id；维度：customer_id、order_date。",
        "- 金额：CNY，最多两位小数，按整数分存储；禁止浮点金额求和。",
        "- 有效订单：paid、completed；cancelled 不计入有效金额。",
        "- DWD 保留输入全部记录；DWS 按有效订单的 order_date 汇总。",
        f"- 实际输入：{model['input']['rows']} 行；SHA-256：{model['input']['sha256']}。",
        "- 唯一性、日期、负金额及金额/行数对账由独立质量 Mod 实际检查。",
        "- 自动检查不代替需求负责人确认；businessAcceptance=needs_review。", ""])


def build(feature_dir: Path) -> dict:
    model = contract(feature_dir)
    target = folder(feature_dir)
    write(target / "MODEL.json", json.dumps(model, ensure_ascii=False, indent=2) + "\n")
    write(target / "MODEL.md", markdown(model))
    return model


def validate(feature_dir: Path) -> list[str]:
    try:
        expected = contract(feature_dir)
        target = folder(feature_dir)
        if json.loads(read(target / "MODEL.json").decode("utf-8")) != expected:
            return ["模型与实际输入/需求字节不一致；请审阅后重新建模"]
        if read(target / "MODEL.md").decode("utf-8") != markdown(expected):
            return ["模型说明与实际契约不一致"]
        return []
    except (OSError, ValueError, UnicodeError) as error:
        return [str(error)]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["init-demo", "init-csv", "build", "validate"])
    parser.add_argument("--feature-dir", type=Path, required=True)
    parser.add_argument("--csv", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "init-csv" and not args.csv:
            raise ValueError("init-csv 必须显式给出 --csv")
        if args.command.startswith("init-"):
            result = initialize(args.feature_dir, args.csv if args.command == "init-csv" else None)
        elif args.command == "build":
            result = build(args.feature_dir)
        else:
            errors = validate(args.feature_dir)
            print(json.dumps({"ok": not errors, "errors": errors}, ensure_ascii=False))
            raise SystemExit(1 if errors else 0)
        print(json.dumps(result, ensure_ascii=False))
    except (OSError, ValueError, UnicodeError) as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False))
        raise SystemExit(1)
