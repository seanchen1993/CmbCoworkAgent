#!/usr/bin/env python3
"""Run an actual bounded local SQLite transform; never claim production acceptance."""
from __future__ import annotations

import argparse
import csv
from contextlib import closing
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
from pathlib import Path
import sqlite3
import tempfile


def read(path: Path) -> bytes:
    if not path.is_file() or path.is_symlink() or path.stat().st_size > 8 * 1024 * 1024:
        raise ValueError(f"文件缺失、链接或超过 8 MiB：{path.name}")
    return path.read_bytes()


def sha(path: Path) -> str:
    return hashlib.sha256(read(path)).hexdigest()


def folder(feature_dir: Path) -> Path:
    path = feature_dir / "warehouse"
    if (not feature_dir.is_dir() or feature_dir.is_symlink() or not path.is_dir()
            or path.is_symlink() or getattr(path, "is_junction", lambda: False)()):
        raise ValueError("需要当前 Feature 内的普通 warehouse 目录")
    return path


def write(path: Path, text: str) -> None:
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise ValueError("输出不能是目录或链接")
    path.write_text(text, encoding="utf-8", newline="\n")


def inputs(feature_dir: Path) -> tuple[dict, list[dict]]:
    target = folder(feature_dir)
    model = json.loads(read(target / "MODEL.json").decode("utf-8"))
    raw = read(target / "orders.csv")
    if (model.get("apiVersion") != "warehouse.model/v1" or model.get("engine") != "sqlite3"
            or model.get("tables") != {"detail": "dwd_order", "daily": "dws_order_daily"}
            or model.get("validStatuses") != ["paid", "completed"] or model.get("scale") != 2
            or model.get("currency") != "CNY" or model.get("input", {}).get("sha256") != hashlib.sha256(raw).hexdigest()
            or model.get("requestSha256") != sha(target / "INPUT.json")):
        raise ValueError("模型口径或输入字节变化；请先回到建模步骤核对")
    reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
    if reader.fieldnames != ["order_id", "customer_id", "order_date", "amount", "status"]:
        raise ValueError("CSV 列不匹配订单合同")
    rows = list(reader)
    if not rows or len(rows) > 5000:
        raise ValueError("订单记录必须为 1–5000 行")
    for row in rows:
        try:
            amount = Decimal(row["amount"])
            if not amount.is_finite() or amount != amount.quantize(Decimal("0.01")) or abs(amount) > Decimal("999999999.99"):
                raise ValueError("金额不能使用浮点近似、超过两位小数或超出范围")
            row["amount_cents"] = int(amount * 100)
        except (InvalidOperation, TypeError, KeyError) as error:
            raise ValueError("金额或 CSV 记录无效") from error
    return model, rows


def quote(value: str) -> str:
    if not isinstance(value, str) or "\x00" in value:
        raise ValueError("字段必须是无 NUL 的文本")
    return "'" + value.replace("'", "''") + "'"


def sql_text(rows: list[dict]) -> str:
    inserts = ["(" + ",".join([quote(row["order_id"]), quote(row["customer_id"]), quote(row["order_date"]),
                               str(row["amount_cents"]), quote(row["status"])]) + ")" for row in rows]
    return "\n".join(["-- Local SQLite order warehouse; amounts are integer CNY cents.", "BEGIN;",
        "CREATE TABLE dwd_order (order_id TEXT NOT NULL, customer_id TEXT NOT NULL, order_date TEXT NOT NULL, amount_cents INTEGER NOT NULL, status TEXT NOT NULL);",
        "INSERT INTO dwd_order VALUES\n" + ",\n".join(inserts) + ";",
        "CREATE TABLE dws_order_daily AS SELECT order_date, COUNT(*) AS order_count, SUM(amount_cents) AS amount_cents FROM dwd_order WHERE status IN ('paid','completed') GROUP BY order_date;",
        "COMMIT;", ""])


def query_results(database: Path) -> dict:
    read(database)
    with closing(sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True)) as connection:
        connection.execute("PRAGMA query_only=ON")
        integrity = connection.execute("PRAGMA quick_check").fetchone()[0]
        detail_rows, raw_cents = connection.execute("SELECT COUNT(*), COALESCE(SUM(amount_cents),0) FROM dwd_order").fetchone()
        valid_rows, valid_cents = connection.execute("SELECT COUNT(*), COALESCE(SUM(amount_cents),0) FROM dwd_order WHERE status IN ('paid','completed')").fetchone()
        daily = [{"order_date": row[0], "order_count": row[1], "amount_cents": row[2]}
                 for row in connection.execute("SELECT order_date,order_count,amount_cents FROM dws_order_daily ORDER BY order_date")]
    if integrity != "ok":
        raise ValueError("SQLite quick_check 失败")
    return {"detailRows": detail_rows, "rawAmountCents": raw_cents,
            "validRows": valid_rows, "validAmountCents": valid_cents, "daily": daily}


def receipt(feature_dir: Path) -> dict:
    target = folder(feature_dir)
    model, rows = inputs(feature_dir)
    if read(target / "orders_transform.sql").decode("utf-8") != sql_text(rows):
        raise ValueError("SQL 与真实模型/CSV 不一致")
    results = query_results(target / "local_orders.sqlite3")
    if json.loads(read(target / "SQL_RESULTS.json").decode("utf-8")) != results:
        raise ValueError("SQL 结果文件与真实数据库不一致")
    return {"apiVersion": "warehouse.sql-run/v1", "executed": True, "engine": "sqlite3",
            "sqliteVersion": sqlite3.sqlite_version, "scope": "local_sqlite_contract_demo",
            "modelSha256": sha(target / "MODEL.json"), "csvSha256": sha(target / "orders.csv"),
            "sqlSha256": sha(target / "orders_transform.sql"), "databaseSha256": sha(target / "local_orders.sqlite3"),
            "resultsSha256": sha(target / "SQL_RESULTS.json"), "results": results,
            "businessAcceptance": "needs_review", "productionAcceptance": "not_evaluated"}


def run(feature_dir: Path) -> dict:
    target = folder(feature_dir)
    _, rows = inputs(feature_dir)
    sql = sql_text(rows)
    for name in ["local_orders.sqlite3", "orders_transform.sql", "SQL_RUN.json", "SQL_RESULTS.json"]:
        path = target / name
        if path.is_symlink() or (path.exists() and not path.is_file()):
            raise ValueError("输出不能是目录或链接")
    with tempfile.NamedTemporaryFile(prefix="local-build-", suffix=".sqlite3", dir=target, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        with closing(sqlite3.connect(temporary)) as connection:
            connection.executescript(sql)
        # Close SQLite before hashing/replacing the actual completed database.
        temporary.replace(target / "local_orders.sqlite3")
    finally:
        if temporary.exists():
            temporary.unlink()
    write(target / "orders_transform.sql", sql)
    results = query_results(target / "local_orders.sqlite3")
    write(target / "SQL_RESULTS.json", json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    result = receipt(feature_dir)
    write(target / "SQL_RUN.json", json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    return result


def validate(feature_dir: Path) -> list[str]:
    try:
        expected = receipt(feature_dir)
        if json.loads(read(folder(feature_dir) / "SQL_RUN.json").decode("utf-8")) != expected:
            return ["SQL 执行回执与实际文件/数据库不一致；请真实重新执行"]
        return []
    except (OSError, ValueError, UnicodeError, sqlite3.Error) as error:
        return [str(error)]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["run", "validate"])
    parser.add_argument("--feature-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "run":
            print(json.dumps(run(args.feature_dir), ensure_ascii=False))
        else:
            errors = validate(args.feature_dir)
            print(json.dumps({"ok": not errors, "errors": errors}, ensure_ascii=False))
            raise SystemExit(1 if errors else 0)
    except (OSError, ValueError, UnicodeError, sqlite3.Error) as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False))
        raise SystemExit(1)
