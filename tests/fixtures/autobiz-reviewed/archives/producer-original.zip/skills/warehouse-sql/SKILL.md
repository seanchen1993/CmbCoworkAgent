---
name: warehouse-sql
description: 将订单模型合同转成实际 SQL，真实运行 SQLite 并保留数据库、结果与执行字节回执。
---

# 订单 SQL 与真实本地执行

1. 阅读本 Feature 的真实 `warehouse/MODEL.json` 和 `MODEL.md`。只有明确 CNY 两位小数、paid/completed 有效、cancelled 排除的订单合同受支持。
2. 用原 `hooks/update_checkpoint.py --checkpoint warehouse_sql_in_progress` 进入阶段；不跳过模型检查或原工具审批。
3. 运行固定的业务脚本，生成并真实执行 SQL。它按整数分入库，DWD 保留全部原始行，DWS 按有效订单日期汇总。不得由模型手写 `SQL_RUN.json`、`SQL_RESULTS.json` 或数据库冒充执行。

```bash
python -X utf8 "${pluginPath}/mods/business/warehouse.sql/check.py" run --feature-dir "${pluginWorkspace}/${projectDir}/.autobizdevops/features/${feature}"
```

4. 查看真实 `orders_transform.sql`、`local_orders.sqlite3`、`SQL_RESULTS.json`、`SQL_RUN.json`。回执记录实际模型、CSV、SQL、数据库和结果字节的 SHA-256；成功只表示本地 SQL 完成，不表示数据质量或生产验收通过。
5. 运行原 `hooks/update_checkpoint.py --checkpoint warehouse_sql_done`。后续独立质量 Mod 会重新读取数据库，对账而不是信任文字总结。
