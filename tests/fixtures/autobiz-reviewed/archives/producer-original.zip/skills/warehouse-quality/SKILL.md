---
name: warehouse-quality
description: 独立读取 CSV 与真实 SQLite 数据，对订单唯一性、行数、状态和整数金额进行对账；失败阻断完成。
---

# 本地订单数仓质量校验

1. 用原 `hooks/update_checkpoint.py --checkpoint warehouse_quality_in_progress` 进入本阶段。前一阶段的 SQL 与数据库字节必须通过原 postcheck。
2. 运行真实质量脚本。它以只读方式查询 SQLite，独立重算 CSV 的十进制金额，检查订单唯一、客户非空、ISO 日期、非负金额、允许状态、每条明细、总行数/总金额、有效订单及按日汇总，并核对真实执行回执和字节哈希。

```bash
python -X utf8 "${pluginPath}/mods/business/warehouse.quality/check.py" check --feature-dir "${pluginWorkspace}/${projectDir}/.autobizdevops/features/${feature}"
```

3. 查看实际生成的 `warehouse/QUALITY.json` 与 `QUALITY.md`。脚本发现错误会写出失败事实并返回非零，必须展示原因并停止；不能删掉失败项、篡改报告、把数据问题称为已通过。修复经用户确认的数据/口径后，按原合法流程重新建模、运行 SQL 和检查。
4. 本地检查通过后才能运行原 `hooks/update_checkpoint.py --checkpoint warehouse_quality_done`。共享内核会再次执行同一 `validate(feature_dir)`：重新查询实际数据并核对报告正文；缺文件、改 SQL/数据库/报告或失败规则均拒绝推进。

`qualityStatus=passed` 仅指本次明确口径的本地 SQLite 检查。`businessAcceptance=needs_review`、`productionAcceptance=not_evaluated` 必须保留。没有连接生产数仓，不宣称生产权限、调度、性能、全量数据或生产发布验收。
