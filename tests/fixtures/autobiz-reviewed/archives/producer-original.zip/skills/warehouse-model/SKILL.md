---
name: warehouse-model
description: 将真实需求、规格和显式订单输入转换为可校验的本地订单数仓模型合同。
---

# 订单数仓建模

本步骤只实现已声明的订单 CNY 口径：order_id 粒度，customer_id/order_date 维度，整数分金额，paid/completed 有效、cancelled 排除。不声称自动理解任意生产数仓。

1. 运行 `python -X utf8 "${pluginPath}/hooks/inspect_skill_contract.py" warehouse-model --feature "${feature}" --plain` 读取当前 Feature 的真实契约，并阅读 PRD、proposal、specs。需求与本口径不符时停止，说明需要扩展业务实现，不得暗改口径。
2. 用原 `hooks/update_checkpoint.py --checkpoint warehouse_model_in_progress` 进入阶段，保留原审批。
3. 用户明确选择“本地五行订单样例”时才执行 `init-demo`。用户提供自己的 CSV 时执行 `init-csv --csv "用户明确给出的文件"`。二者都不覆盖已有输入。没有授权的数据来源时先向用户取得来源。

```bash
python -X utf8 "${pluginPath}/mods/business/warehouse.model/check.py" init-demo --feature-dir "${pluginWorkspace}/${projectDir}/.autobizdevops/features/${feature}"
python -X utf8 "${pluginPath}/mods/business/warehouse.model/check.py" build --feature-dir "${pluginWorkspace}/${projectDir}/.autobizdevops/features/${feature}"
```

4. 向用户展示实际输入行数、粒度、金额及状态口径。`MODEL.json` 绑定 PRD、规格、CSV 与输入声明的实际 SHA-256；`MODEL.md` 是同一合同的可读说明。
5. 运行原 `hooks/update_checkpoint.py --checkpoint warehouse_model_done`。下游 SQL 阶段前，原 postcheck 会重新核对真实文件。输入或需求变更时须重新审阅并建模。

演示数据是公开标记的本地样本，不是真实生产订单；业务认可保持 `needs_review`。
